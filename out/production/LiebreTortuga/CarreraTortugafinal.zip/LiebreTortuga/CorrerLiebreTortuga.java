package LiebreTortuga;



public class CorrerLiebreTortuga {
    public static void main( String[] args) {
      VentanaSeleccionarTortugaLiebre v1 = new VentanaSeleccionarTortugaLiebre("Carrera Liebre Tortuga", 450, 80, false, true);
    }
}
