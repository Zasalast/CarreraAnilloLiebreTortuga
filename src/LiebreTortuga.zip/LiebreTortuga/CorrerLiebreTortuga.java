package LiebreTortuga;

import java.util.Random;

public class CorrerLiebreTortuga {
    public static void main(String[] args) {
      VentanaSeleccionarTortugaLiebre v1 = new VentanaSeleccionarTortugaLiebre("Carrera Liebre Tortuga", 450, 80, false, true);
//        Random randomGenerator=new Random();
//        System.out.println((int) (Math.random()*20));
//        System.out.println(randomGenerator.nextInt(20 - 5 + 1) + 5);
//        System.out.println(randomGenerator.nextInt(20) + 1);

    }
}
